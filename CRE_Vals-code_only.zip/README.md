# Outline
Contains code for downloading, exploring, and working with Tailte Éireann's Valuations Data, from their Open API. 

`0_data_extraction.R` downloads the code directly from TÉ. R scripts starting with `1` are exploratory files, `2` are for files that went into the final FSN. 

-- Sameer Shaikh, 2024-06-19. 

P.S: Please learn the awesomeness of Git. It will rock your world.
BPLIM has a Git workshop, so does Luis Fonseca, and Bocconi's LEAP Website has several learning resources. 